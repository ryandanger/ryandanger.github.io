NiceMeme
-------------

Nice meme, friend!

https://twitter.com/phillipten/status/609558383406886912

GPLv3 license. Really, just do whatever you want with this code.
